from django.apps import AppConfig
from tensorflow.keras.models import  load_model
from tensorflow.keras import backend as K
import tensorflow.keras
from tensorflow.keras.applications.vgg16 import VGG16
import tensorflow as tf
class DetectionConfig(AppConfig):
    name = 'Detection'
    tensorflow.keras.backend.clear_session()
    K.clear_session()
    #model = load_model('model/vgg16.h5')
    gpu_options = tf.compat.v1.GPUOptions(per_process_gpu_memory_fraction=0.333)
    sess = tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(gpu_options=gpu_options))
    model = VGG16(weights='imagenet')
    model._make_predict_function()