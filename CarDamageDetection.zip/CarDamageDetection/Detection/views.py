# Create your views here.
from django.http import HttpResponse 
from django.shortcuts import render, redirect 
from .forms import *
from django.conf import settings
import os
from .CarDetectionModel import car_categories_gate
# Create your views here. 
def hotel_image_view(request): 
    print(request)
    if request.method == 'POST': 
        form = HotelForm(request.POST, request.FILES) 
        print (request.FILES)
        if form.is_valid(): 
            #print(str(request.FILES['hotel_Main_Img'].name))
            filename = os.path.join(settings.BASE_DIR+'/media/images/',str(request.FILES['hotel_Main_Img'].name))
            files = Hotel.objects.filter(hotel_Main_Img=filename)

            if files.count() ==0:
                newform =form.save()
                caname =car_categories_gate(os.path.join(settings.BASE_DIR+'/media/images/',str(request.FILES['hotel_Main_Img'].name)))
                try:
                    print(newform.pk)
                    #form.carname=caname
                    #form.save
                    p = Hotel.objects.get(id=newform.pk)
                    p.carname = caname
                    p.save()
                except:
                    print('Erororoor')
                    p = Hotel.objects.get(id=newform.pk)
                    p.carname = 'No vehical Found'
                    p.save()
                return render(request, 'index.html', {'form' : form,'image':p}) 
    else:
        form = HotelForm() 
        return render(request, 'index.html', {'form' : form}) 
def success(request): 
    return HttpResponse('successfully uploaded') 

def display_hotel_images(request): 
  
    if request.method == 'GET': 
        # getting all the objects of hotel. 
        Hotels = Hotel.objects.all()
        
        return render(request, 'display_hotel_images.html',{'hotel_images' : Hotels})