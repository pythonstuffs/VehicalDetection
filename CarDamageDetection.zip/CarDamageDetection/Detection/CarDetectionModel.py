#
import urllib
from IPython.display import Image, display, clear_output
from collections import Counter, defaultdict

#import matplotlib.pyplot as plt
#import seaborn as sns 
#%matplotlib inline

import json
import pickle as pk
from sklearn.metrics import classification_report, confusion_matrix


#
import os
import h5py
import numpy as np
import pandas as pd
import tensorflow as tf
from keras.utils.data_utils import get_file
from keras.applications.resnet50 import ResNet50
from keras.applications.vgg16 import VGG16
from keras.applications.vgg19 import VGG19
from keras.applications.inception_v3 import InceptionV3
from keras.applications.imagenet_utils import preprocess_input, decode_predictions
from keras.preprocessing.image import ImageDataGenerator, array_to_img, img_to_array, load_img
from keras.models import Sequential, load_model
from keras.layers import Convolution2D, MaxPooling2D, ZeroPadding2D
from keras.layers import Activation, Dropout, Flatten, Dense
from keras.utils.np_utils import to_categorical
from keras import optimizers
import keras
from keras.callbacks import ModelCheckpoint, History
from tensorflow.python.keras.backend import set_session
from .apps import DetectionConfig
CLASS_INDEX = None
CLASS_INDEX_PATH = 'model/classification.json'


# from Keras GitHub	 
def get_predictions(preds, top=5):
	global CLASS_INDEX
	if len(preds.shape) != 2 or preds.shape[1] != 1000:
		raise ValueError('`decode_predictions` expects '
						 'a batch of predictions '
						 '(i.e. a 2D array of shape (samples, 1000)). '
						 'Found array with shape: ' + str(preds.shape))
	if CLASS_INDEX is None:
		fpath = get_file('imagenet_class_index.json',
						 CLASS_INDEX_PATH,
						 cache_subdir='models')
		CLASS_INDEX = json.load(open(fpath))
	results = []
	for pred in preds:
		top_indices = pred.argsort()[-top:][::-1]
		result = [tuple(CLASS_INDEX[str(i)]) + (pred[i],) for i in top_indices]
		result.sort(key=lambda x: x[2], reverse=True)
		results.append(result)
	return results
	

def get_model():
	#with open('model/vgg16.h5', 'rb') as f:
	model = load_model('model/vgg16.h5')
	return model
	#'vgg16.h5'
def prepare_image(img_path):
	img = load_img(img_path, target_size=(224, 224))
	x = img_to_array(img)
	x = np.expand_dims(x, axis=0)
	x = preprocess_input(x)
	return x
	
# Load pickel file
def returnCategories():
	with open('model/categories.pk', 'rb') as f:
		cat_counter = pk.load(f)
	return [k for k, v in cat_counter.most_common()[:80]]
		
def car_categories_gate(image_path):
	#urllib.request.urlretrieve(image_path, 'save.jpg') # or other way to upload image
	#session = tf.Session()
	#graph = tf.get_default_graph()
	#keras.backend.set_session(session)
	img = prepare_image(image_path)
	model = DetectionConfig.model
	#with session.as_default():
	#	with session.graph.as_default():
	out = model.predict(img)
	top	 = get_predictions(out, top=5)
	print ("Validating that this is a picture of your car...")
	for j in top[0]:
		if j[0:2] in returnCategories():
			print (j[0:2])
			return str(j[1])
	return "Are you sure this is a picture of your car? Please take another picture (try a different angle or lighting) and try again."