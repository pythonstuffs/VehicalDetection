from django.contrib import admin
from Detection.models import Hotel
# Register your models here.
admin.site.register(Hotel)